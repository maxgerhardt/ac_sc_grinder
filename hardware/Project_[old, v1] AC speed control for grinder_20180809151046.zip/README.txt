Speed control for grinders with sensorless RPM tracking.

Additional purchases after BOM:

- [Plastik 70](https://www.google.ru/search?q=plastik+70) protective acrylic spray (cover board after asssemble)
- [ST-Link V2](https://ru.aliexpress.com/wholesale?SearchText=stm32+programmer) to load stm32 firmware.

Extract from original board:

- RPM resistor with wheel
- Pins for motor terminals            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。